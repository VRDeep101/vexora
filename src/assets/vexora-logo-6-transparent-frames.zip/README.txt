VEXORA LOGO FRAME PACK

Contents:
- frame_01_dormant.png
- frame_02_opening.png
- frame_03_building.png
- frame_04_peak.png
- frame_05_settling.png
- frame_06_closing.png
- preview_loop.gif

All PNG frames:
- RGBA PNG with transparent background
- Same 900 x 300 canvas for stable frame-by-frame playback
- Center-aligned logo to reduce unwanted jumping between frames

Suggested playback order:
1 -> 2 -> 3 -> 4 -> 5 -> 6 -> repeat

Suggested timing:
- Frames 1-3: 100-140 ms each
- Frame 4: 160-200 ms
- Frames 5-6: 120-160 ms each

Note:
These are six separated crops from the generated concept sheet, normalized to a shared canvas.
For the cleanest animation, keep the logo element at one fixed CSS size and swap the PNG source
at a steady interval. A short opacity/scale interpolation between frames can make the loop smoother.
